# AI 创作平台 部署说明

## 启动
1. 服务器需 Node.js ≥18（自带 fetch）
2. npm install express cors
3. pm2 start server.js --name ai-platform && pm2 save
4. 访问 http://服务器IP:3001/

## 管理
- 管理后台 http://服务器IP:3001/admin.html （账号 admin）
- 改积分价格：config.js 的 PRICE 字段，改完 pm2 restart ai-platform
- 手动加积分：admin.html 用户列表里点充值即可

## 文件
- public/hs.html 前端主页面；admin.html 管理后台
- data/key.txt updrama API Key（勿外泄）；users.json 注册用户数据（含密码哈希）
