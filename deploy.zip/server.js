// ===== 林攻略 AI 创作平台后端 =====
// 用户注册/登录、积分、生成代理（Key 在服务端，安全）
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('./config');

const app = express();
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data', 'users.json');

// ===== 数据工具 =====
function loadUsers(){ try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); } catch(e){ return []; } }
function saveUsers(list){ fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 1)); }
function hash(pw, salt){ return crypto.createHash('sha256').update(salt + pw).digest('hex'); }
function findUser(token){ return loadUsers().find(u => u.token === token); }

// 读取 updrama Key（环境变量 > data/key.txt）
function udramaKey(){
  if (process.env.UDRAMA_API_KEY) return process.env.UDRAMA_API_KEY.trim();
  try { const k = fs.readFileSync(path.join(__dirname, 'data', 'key.txt'), 'utf-8').trim(); if (k && k.startsWith('sk-')) return k; } catch(e){}
  return config.UDRAMA_KEY;
}

// ===== 认证 =====
function auth(req, res, next){
  const token = (req.headers.authorization || '').replace('Bearer ', '') || req.query.token;
  const user = token ? findUser(token) : null;
  if (!user) return res.json({ ok: false, error: '请先登录' });
  req.user = user; req.userIndex = loadUsers().findIndex(u => u.id === user.id);
  next();
}

// ===== 注册 =====
app.post('/api/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.json({ ok: false, error: '请填写用户名和密码' });
  const uname = String(username).trim();
  if (!uname) return res.json({ ok: false, error: '请填写用户名' });
  if (String(password).length < 8) return res.json({ ok: false, error: '密码至少8位' });
  const users = loadUsers();
  if (users.some(u => u.username === username)) return res.json({ ok: false, error: '用户名已存在' });
  const user = {
    id: Date.now().toString(),
    username,
    salt: crypto.randomBytes(8).toString('hex'),
    password: '',
    coins: config.REGISTER_BONUS,
    token: crypto.randomBytes(16).toString('hex'),
    createdAt: Date.now(),
    history: [],
    ledger: [{ type: 'bonus', amount: config.REGISTER_BONUS, ts: Date.now(), note: '注册赠送' }]
  };
  user.password = hash(password, user.salt);
  users.push(user);
  saveUsers(users);
  res.json({ ok: true, token: user.token, username: user.username, coins: user.coins, bonus: config.REGISTER_BONUS });
});

// ===== 登录 =====
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const users = loadUsers();
  const user = users.find(u => u.username === username);
  if (!user || user.password !== hash(password, user.salt)) return res.json({ ok: false, error: '用户名或密码错误' });
  user.token = crypto.randomBytes(16).toString('hex');
  saveUsers(users);
  res.json({ ok: true, token: user.token, username: user.username, coins: user.coins });
});

// ===== 我的信息 =====
app.get('/api/me', auth, (req, res) => {
  res.json({ ok: true, username: req.user.username, coins: req.user.coins, history: (req.user.history || []).slice(0, 50) });
});

// ===== 积分预检（生成前检查余额，不扣） =====
app.post('/api/precheck', auth, (req, res) => {
  const { type, count } = req.body || {};
  const n = Math.max(parseInt(count) || 1, 1);
  const price = Math.round((config.PRICE[type] || config.PRICE.image) * n * 10) / 10;
  if ((req.user.coins || 0) < price) return res.json({ ok: false, error: '积分不足，本次需要 ' + price + ' 积分，余额 ' + req.user.coins + ' 积分' });
  res.json({ ok: true, price, coins: req.user.coins });
});

// ===== 积分扣费（任务提交成功后调用） =====
app.post('/api/commit', auth, (req, res) => {
  const { type, count, taskId, note } = req.body || {};
  const n = Math.min(Math.max(parseInt(count) || 1, 1), 20);
  const price = Math.round((config.PRICE[type] || config.PRICE.image) * n * 10) / 10;
  const users = loadUsers();
  const u = users.find(x => x.id === req.user.id);
  if (!u) return res.json({ ok: false, error: '用户不存在' });
  if ((u.coins || 0) < price) return res.json({ ok: false, error: '积分不足，需 ' + price + ' 积分' });
  u.coins = Math.round((u.coins - price) * 10) / 10;
  u.history = u.history || [];
  u.history.unshift({ id: Date.now().toString() + '_' + Math.random().toString(36).slice(2,6), type: type || 'image', prompt: note || '', taskId: taskId || '', cost: price, ts: Date.now() });
  u.ledger = u.ledger || [];
  u.ledger.unshift({ type: 'spend', amount: -price, ts: Date.now(), note: (type === 'video' ? '视频生成 x' : '图片生成 x') + n });
  saveUsers(users);
  res.json({ ok: true, coins: u.coins, cost: price });
});

// ===== 生成（先扣积分，再提交任务） =====
app.post('/api/generate', auth, async (req, res) => {
  try {
    const { type, model, prompt, size, images, duration } = req.body || {};
    const price = config.PRICE[type] || config.PRICE.image;
    if (req.user.coins < price) return res.json({ ok: false, error: '积分不足，需要 ' + price + ' 积分，当前 ' + req.user.coins + ' 积分' });
    const key = udramaKey();
    if (!key) return res.json({ ok: false, error: '服务端未配置 API Key' });

    // 提交 updrama 任务
    const params = { size, duration };
    if (type === 'image') params.n = 1;
    const body = { model: model || 'tt-image-2', prompt, images: images || [] };
    if (params.size) body.size = params.size;
    if (params.duration) body.duration = params.duration;
    if (params.n) body.n = params.n;
    if (type === 'video') body.params = { ratio: '16:9', duration: duration || 5 };

    const resp = await fetch(config.UDRAMA_URL + '/media/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
      body: JSON.stringify(body)
    });
    const data = await resp.json();
    if (data.code !== 200) return res.json({ ok: false, error: data.msg || '任务提交失败' });

    // 扣积分（提交成功才扣）
    const users = loadUsers();
    const u = users.find(x => x.id === req.user.id);
    u.coins -= price;
    u.history = u.history || [];
    u.history.unshift({ id: Date.now().toString() + '_' + Math.random().toString(36).slice(2,6), type, prompt, taskId: data.data.task_id, cost: price, ts: Date.now() });
    saveUsers(users);
    res.json({ ok: true, task_id: data.data.task_id, cost: price, coins: u.coins });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== 任务状态（轮询） =====
app.get('/api/task-status', auth, async (req, res) => {
  try {
    const key = udramaKey();
    const resp = await fetch(config.UDRAMA_URL + '/skills/task-status?task_id=' + req.query.task_id, {
      headers: { 'Authorization': 'Bearer ' + key }
    });
    const data = await resp.json();
    res.json(data);
  } catch (e) {
    res.json({ error: e.message });
  }
});

// ===== 管理后台：用户列表 =====
app.get('/api/admin/users', (req, res) => {
  const { u, p } = req.query;
  if (u !== config.ADMIN.username || p !== config.ADMIN.password) return res.json({ ok: false, error: '管理员验证失败' });
  const users = loadUsers().map(x => ({ id: x.id, username: x.username, coins: x.coins, createdAt: x.createdAt, historyCount: (x.history || []).length }));
  res.json({ ok: true, users });
});

// ===== 管理后台：充值 =====
app.post('/api/admin/charge', (req, res) => {
  const { u, p, userId, amount } = req.body || {};
  if (u !== config.ADMIN.username || p !== config.ADMIN.password) return res.json({ ok: false, error: '管理员验证失败' });
  const amountN = parseInt(amount);
  if (!amountN) return res.json({ ok: false, error: '金额无效' });
  const users = loadUsers();
  const user = users.find(x => x.id === userId);
  if (!user) return res.json({ ok: false, error: '用户不存在' });
  user.coins += amountN;
  saveUsers(users);
  res.json({ ok: true, coins: user.coins, username: user.username });
});


// ===== 充值码 =====
const CODE_FILE = path.join(__dirname, 'data', 'codes.json');
function loadCodes(){ try { return JSON.parse(fs.readFileSync(CODE_FILE, 'utf-8')); } catch(e){ return {}; } }
function saveCodes(c){ fs.writeFileSync(CODE_FILE, JSON.stringify(c, null, 1)); }

// 管理员生成充值码
app.post('/api/admin/gen-codes', (req, res) => {
  const { u, p, amount, count } = req.body || {};
  if (u !== config.ADMIN.username || p !== config.ADMIN.password) return res.json({ ok: false, error: '管理员验证失败' });
  const amountN = parseInt(amount), countN = Math.min(parseInt(count) || 1, 100);
  if (!amountN || amountN <= 0) return res.json({ ok: false, error: '面额无效' });
  const codes = loadCodes();
  const list = [];
  for (let i = 0; i < countN; i++) {
    const code = 'LG' + crypto.randomBytes(4).toString('hex').toUpperCase();
    codes[code] = { amount: amountN, used: false };
    list.push(code);
  }
  saveCodes(codes);
  res.json({ ok: true, codes: list, amount: amountN });
});

// 用户兑换充值码
app.post('/api/redeem', auth, (req, res) => {
  const code = String((req.body || {}).code || '').trim().toUpperCase();
  if (!code) return res.json({ ok: false, error: '请输入充值码' });
  const codes = loadCodes();
  const c = codes[code];
  if (!c) return res.json({ ok: false, error: '充值码不存在' });
  if (c.used) return res.json({ ok: false, error: '充值码已使用' });
  c.used = true; c.usedBy = req.user.username; c.usedAt = Date.now();
  saveCodes(codes);
  const users = loadUsers();
  const u = users.find(x => x.id === req.user.id);
  u.coins += c.amount;
  u.ledger = u.ledger || [];
  u.ledger.unshift({ type: 'recharge', amount: c.amount, ts: Date.now(), note: '充值码兑换' });
  saveUsers(users);
  res.json({ ok: true, coins: u.coins, amount: c.amount });
});

// 积分明细
app.get('/api/ledger', auth, (req, res) => {
  res.json({ ok: true, coins: req.user.coins, ledger: (req.user.ledger || []).slice(0, 50) });
});


// ===== 页面自动同步（本地开发：桌面文件更新后自动复制） =====
try {
  const srcPage = 'D:\\桌面\\hs.html';
  const dstPage = path.join(__dirname, 'public', 'hs.html');
  if (fs.existsSync(srcPage) && (!fs.existsSync(dstPage) || fs.statSync(srcPage).mtimeMs > fs.statSync(dstPage).mtimeMs)) {
    fs.copyFileSync(srcPage, dstPage);
    console.log('[平台] 页面已自动同步最新版');
  }
} catch(e) {}
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'hs.html')));
app.listen(config.PORT, () => {
  console.log('[平台] 服务启动 http://0.0.0.0:' + config.PORT);
  console.log('[平台] updrama Key: ' + (udramaKey() ? '已配置' : '未配置（放 data/key.txt 或环境变量 UDRAMA_API_KEY）'));
  console.log('[平台] 图片 ' + config.PRICE.image + ' 积分/张, 视频 ' + config.PRICE.video + ' 积分/次');
});
