// ===== 平台配置（价格在这里改） =====
module.exports = {
  PORT: 3001,
  // 积分价格（按次扣费）
  PRICE: { image: 0.8, video: 1, product: 0.8 },
  // 注册赠送积分
  REGISTER_BONUS: 10,
  // 管理员账号（部署后请修改）
  ADMIN: { username: "admin", password: "13140902q" },
  // updrama API
  UDRAMA_URL: "https://api.lk888.ai/v1",
  UDRAMA_KEY: "" // 从环境变量 UDRAMA_API_KEY 或 data/key.txt 读取
};
