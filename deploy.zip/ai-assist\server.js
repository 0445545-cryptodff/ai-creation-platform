// ===== 林攻略平台 AI 辅助服务 =====
// 依赖：express + cors；Key 从 D:\桌面\xiaomi_key.txt 读取（小米 Token Plan）
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const PORT = 3900;
const XIAOMI_URL = 'https://token-plan-cn.xiaomimimo.com/v1/chat/completions';
const MODEL = 'mimo-v2.5-pro';

// 读取小米 Key（支持 环境变量 > xiaomi_key.txt）
function getKey() {
  if (process.env.XIAOMI_API_KEY) return process.env.XIAOMI_API_KEY.trim();
  try {
    const p = path.join('D:\\', '桌面', 'xiaomi_key.txt');
    const k = fs.readFileSync(p, 'utf-8').trim();
    if (k && k.startsWith('tp-') && !k.includes('请把')) return k;
  } catch (e) {}
  return '';
}

const app = express();
app.use(cors()); // 允许所有来源（file:// 页面也能调用）
app.use(express.json({ limit: '2mb' }));

async function aiChat(messages) {
  const key = getKey();
  if (!key) throw new Error('未找到小米 API Key（检查 xiaomi_key.txt）');
  const res = await fetch(XIAOMI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: MODEL, messages, temperature: 0.7 })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error('AI 服务错误 ' + res.status + ': ' + t.slice(0, 200));
  }
  const data = await res.json();
  const content = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!content) throw new Error('AI 返回为空');
  return content.trim();
}

// ===== 1. AI 优化商品提示词 =====
app.post('/api/assist/prompt', async (req, res) => {
  try {
    const { desc, platform, type } = req.body || {};
    if (!desc || !desc.trim()) return res.json({ ok: false, error: '请先填写商品信息' });
    let sys;
    if (type === 'video') {
      sys = '你是资深短视频导演和 AI 视频生成专家，擅长为 AI 视频生成工具写提示词。请把用户提供的主题描述，改写成一段专业、详细、可直接用于 AI 视频生成的提示词（中文，150-300字）。要求包含：画面主体与场景、主体运动方式（动作/位移/变化）、镜头语言（推拉摇移/景别）、光线氛围与色调、画面节奏、是否包含人物动作或物体动态，时长约 ' + (req.body.duration || 10) + ' 秒。只输出提示词正文，不要解释、不要加引号。';
    } else {
      sys = '你是资深电商运营专家，擅长为 AI 生图工具写提示词。请把用户提供的商品信息，改写成一段专业、详细、可直接用于 GPT Image 2 图生图的提示词（中文，150-300字）。要求包含：商品主体与细节、材质质感、场景与背景、光线氛围、构图方式、电商平台风格（' + (platform || '淘宝') + '）、最终输出为' + (type === 'plain' ? '纯商品主图（浅色干净背景，产品居中，专业商品摄影）' : '电商详情页首图（竖版2:3，大标题+卖点+促销条排版）') + '。只输出提示词正文，不要解释、不要加引号。';
    }
    const prompt = await aiChat([
      { role: 'system', content: sys },
      { role: 'user', content: '商品信息：' + desc }
    ]);
    res.json({ ok: true, prompt });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== 2. 健康检查 =====
app.get('/api/health', (req, res) => {
  res.json({ ok: true, key: getKey() ? '已配置' : '未配置', time: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log('[ai-assist] 服务已启动: http://127.0.0.1:' + PORT);
  console.log('[ai-assist] Key: ' + (getKey() ? '已配置' : '未配置（请把小米 Key 放入桌面 xiaomi_key.txt）'));
});
